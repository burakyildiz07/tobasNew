<?php $__env->startSection('title', 'Yönetim Paneli'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-crm">
                    <div class="panel-heading">
                        <h1><i class="fa fa-eye" aria-hidden="true"></i> Sayfaları Görüntüle</h1>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-crm">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Sayfa Adı</th>
                                    <th></th>
                                    <th></th>
                                    <th class="col-sm-1">İşlemler</th>
                                </tr>
                                </thead>
                                <tbody>

                                    <tr>
                                        <th scope="row"></th>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>
                                            <div class="btn-group btn-group-justified" role="group">
                                                <div class="btn-group" role="group">
                                                    <a type="button" class="btn btn-xs btn-info" href="" role="button"><span class="fa fa-eye" aria-hidden="true"></span></a>
                                                </div>
                                                <div class="btn-group" role="group">
                                                    <a type="button" class="btn btn-xs btn-warning" href="" role="button"><span class="fa fa-pencil" aria-hidden="true"></span></a>
                                                </div>
                                                <div class="btn-group" role="group">
                                                    <button type="button" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#removeModal" data-id="" data-group="" data-first_name="" data-last_name="">
                                                        <span class="fa fa-trash-o" aria-hidden="true"></span>
                                                    </button>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <div class="btn-group btn-group-justified" role="group">
                            <div class="btn-group" role="group">
                                <a type="button" class="btn btn-xl btn-success" href="<?php echo e(route('manager.pages-create')); ?>" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Yeni Bir Sayfa Oluştur</a>
                            </div>
                            <div class="btn-group" role="group">
                                <a type="button" class="btn btn-xl btn-info" href="" role="button"><i class="fa fa-eye" aria-hidden="true"></i> Müşteri Gruplarını Görüntüle</a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('manager.layouts.common', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>