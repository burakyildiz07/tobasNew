<?php $__env->startSection('title', 'Giriş'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-offset-3 col-md-6 auth-box">
                <img alt="Brand" src="<?php echo e(asset('assets/images/auth-logo.png')); ?>" class="img-responsive center-block" />
                <h1 class="text-center">Hesabınıza giriş yapın...</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-md-offset-3 col-md-6 auth-box">
                <?php echo e(Form::open(array('url'=>route('login'), 'method'=>'post', 'id'=>'auth-form', 'autocomplete'=>'off'))); ?>

                <div class="row">
                    <div class="form-group form-group-lg col-md-12">
                        <div class="input-group">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-user" aria-hidden="true"></span></span>
                            <?php echo e(Form::text('email', '', array('id' => 'email', 'class' => 'form-control', 'placeholder' => 'Kullanıcı adınızı girin'))); ?>

                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group form-group-lg col-md-12">
                        <div class="input-group">
                            <span class="input-group-addon"><span class="glyphicon glyphicon-console" aria-hidden="true"></span></span>
                            <?php echo e(Form::password('password', array('id' => 'password', 'class' => 'form-control', 'placeholder' => 'Şifrenizi girin'))); ?>

                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-12">
                        <?php echo e(Form::submit('Giriş', array('class' => 'btn btn-success btn-lg btn-block'))); ?>

                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('manager.layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>