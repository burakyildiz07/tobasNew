<?php

namespace App\Http\Controllers\Manager;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PagesController extends Controller
{
    public function index()
    {
        return view('manager.pages.index');
    }

    public function create()
    {
        return view('manager.pages.create');
    }
}
