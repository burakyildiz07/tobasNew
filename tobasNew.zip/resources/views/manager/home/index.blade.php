@extends('manager.layouts.common')
@section('title', 'Yönetim Paneli')
@section('content')

@endsection