<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


/*
 * MANAGER Routes
 */

Route::group(['prefix'=>'manager'],function (){

    Route::get('/',['uses'=>'Manager\HomeController@index','as'=>'manager.home']);
    Route::get('/pages',['uses'=>'Manager\PagesController@index','as'=>'manager.pages']);
    Route::get('/pages/create',['uses'=>'Manager\PagesController@create','as'=>'manager.pages-create']);


});
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
